
import logo from './logo.svg';
import './App.css';
 
/*
function App() {
  const userName = "Umar Rahman";
  return (
   <>
     <Home userName={userName}> Main Content</Home>
   </>
  );
}
 function Home({children, userName}){
   return(
     <>
     <About userName={userName} />
     {children}
     
     </>
   )
 }
 
 function About({userName}){
  return(
    <>
     <Services userName={userName} />
    </>
  )
}
 
 
function Services({userName}){
  return(
    <>
      <div>{userName}</div>
    </>
  )
}
 
*/

/*
import React, {useState, useContext } from "react";

const employeeContext=React.createContext();
 

function App(){
  const empData ={
    id:32,
    Name:'Karim',
    Location:'Kolkata',
    Salary:12345
  }
  const [employee,setEmployee] = useState(empData);
  return(
    <>
      <h1>Welcome to Context API EXample</h1>
      <employeeContext.Provider value ={employee}>
          <Employee></Employee>
          <Salary></Salary>
      </employeeContext.Provider>
    
    </>
  )
}





function Employee(){
 let context=useContext(employeeContext);
 return(
      <>
      <div>
      <h2>Employee Component</h2>
          
          <h3> Employee Name = {context.Name}</h3>

          <h3> Employee Location = {context.Location}</h3>

      </div>
           
      </>
    )
}





function Salary(){
  let context=useContext(employeeContext);
  return(
       <>
       <div>
       <h2>Salary Component</h2>  
           <h3> Employee ID = {context.id}</h3>

           <h3> Employee Name = {context.Name}</h3>
 
           <h3> Employee Location = {context.Salary}</h3>
 
       </div>
         
       </>
     )
 }

 */
 import React, { Component, useContext, useState, useEffect } from "react";

 const ThemeContext=React.createContext(null);

 function App(){

  const [color, setColor] = useState("Green");
  return(
    <>
       <ThemeContext.Provider value={{ color, setColor }}>

       <h3>
         Color in Parent: <span style={{ color: color }}>{color}</span>
       </h3>

        <ChangeColor></ChangeColor>

       </ThemeContext.Provider>
    </>
  )
}
 
function ChangeColor(){
  const { color, setColor } = React.useContext(ThemeContext);
 useEffect(()=>{
    console.info("Context Updated :", color);
 },
 [color]
 )


 const handleClick = () => {
       setColor(color === "Green" ? "Red" : "Green");
 }

  return(
    <>
     <button onClick={handleClick} style={{BackroundColor:color}} >Change Color From Child Componeent</button>
    </>
  )
}

export default App;



























/*


 import React, { Component, useContext, useState, useEffect } from "react";
 const ThemeContext = React.createContext(null);
  
 const App = () => {
   const [color, setColor] = useState("Green");
  
   return (
     <ThemeContext.Provider value={{ color, setColor }}>
       <h1>React Context Demo</h1>
       included:
       <ul>
         <li>createContext</li>
         <li>share state via Provider</li>
         <li>useContext</li>
         <li>change value in child component</li>
       </ul>
       <h3>
         Color in Parent: <span style={{ color: color }}>{color}</span>
       </h3>
       <ChangeColor />
     </ThemeContext.Provider>
   );
 };
  
  
 const ChangeColor = () => {
  
   const { color, setColor } = React.useContext(ThemeContext);
  
   useEffect(() => {
     console.info("Context changed:", color);
   }, [color]);
  
   const handleClick = () => {
     console.info("handleClick");
     setColor(color === "blue" ? "red" : "blue");
   };
  
   return (
     <button
       type="button"
       onClick={handleClick}
       style={{ backgroundColor: color, color: "white" }}
     >
       toggle color in Child
     </button>
   );
 };
  
  

 







 
export default App;
*/